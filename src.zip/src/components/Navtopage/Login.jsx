import React, { useState } from 'react';
import './styles/Login.css';

const Login = () => {
  const [showEmailLogin, setShowEmailLogin] = useState(false);

  const handleEmailLoginClick = () => {
    setShowEmailLogin(true);
  };

  const handleStayLoggedOutClick = () => {
    setShowEmailLogin(false);
  };

  return (
    <div className="login-container">
      <div className="login-card">
        {!showEmailLogin ? (
          <>
            <h1 className="login-title">Log in to your account</h1>
            <p className="login-subtitle">Welcome back !!!</p>

            <button className="login-google-btn">
              <img src="{googleIcon}" alt="Google Icon" className="login-google-icon" />
              Continue with google
            </button>

            <button className="login-email-btn" onClick={handleEmailLoginClick}>
              Continue with number /email
            </button>

            <button className="login-stay-logged-out-btn" onClick={handleStayLoggedOutClick}>
              Stay logged out
            </button>

            <p className="login-signup-text">
              Don’t have an account? <a href="/signup" className="login-signup-link">Sign up</a>
            </p>
          </>
        ) : (
          <>
            <h1 className="login-title">Log In</h1>
            <p className="login-subtitle">Enter your Registered Mobile no or Email</p>

            <form className="login-form">
              <label className="login-label">Mobile no / Email</label>
              <input
                type="text"
                className="login-input"
                placeholder=""
                required
              />

              <label className="login-label">Password</label>
              <input
                type="password"
                className="login-input"
                placeholder=""
                required
              />

              <button type="submit" className="login-submit-btn">
                Log In
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
};

export default Login;