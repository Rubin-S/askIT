import React, { useState, useEffect } from 'react';
import { useNavigate } from "react-router-dom";
import OTP from "../Signup/OTP";

const Form2 = (onSaveAndContinue) => {
    const navigate = useNavigate();

    const handleSubmit = () => {
        onSaveAndContinue(); // Pass form data to the parent component
    };

    const [showOTP, setShowOTP] = useState(false); 
    const [otp, setOTP] = useState(''); 
    const [isVerified, setIsVerified] = useState(false);
    
    const [formData, setFormData] = useState({
        name: '',
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        agreeToTerms: false
    });


    const handleOTPChange = (enteredOTP) => {
        setOTP(enteredOTP);
        if (enteredOTP.length === 6) {
            setShowOTP(false); 
            setIsVerified(true);
            // add validating the OTP logic here
        }
    };


    const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };
  return (
    <div className="verify-form">
        <div className="verify-form-group">
            <label className="verify-label">Join AskIT - Find & Connect Instantly!</label>
            <div className='verify-button-group-hor'>
                <div className='verify-button-group-ver'>
                    <label htmlFor="name" className="verify-label">Name*</label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        disabled={isVerified} // Disable input if verified
                        className={isVerified ? 'verify-phone-disabled' : 'verify-phone-input'}
                        required
                    />
                </div>
                <div className='verify-button-group-ver'>
                    <label htmlFor="username" className="verify-label">Username*</label>
                    <input
                        type="text"
                        id="username"
                        name="username"
                        value={formData.username}
                        onChange={handleChange}
                        disabled={isVerified} // Disable input if verified
                        className={isVerified ? 'verify-phone-disabled' : 'verify-phone-input'}
                        required
                    />
                </div>
            </div>
            <div className="verify-mobile-input">
                <label htmlFor="email" className="verify-label">
                    Email*
                </label>
                <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    placeholder="Xyz@abc.com"
                    onChange={handleChange}
                    className={isVerified ? 'verify-phone-disabled' : 'verify-phone-input'}
                    required
                />
                <button 
                        className={`verify-button ${isVerified ? 'verify-button-verified' : ''}`}
                        onClick={() => setShowOTP(true)}
                        disabled={isVerified}
                    >
                        {isVerified ? 'Verified' : 'Verify Now'}
                </button>
                {showOTP && (
                        <div className="verify-popup-overlay">
                        <OTP
                            onOTPChange={handleOTPChange}
                            onClose={() => setShowOTP(false)}
                        />
                        </div>
                )}
            </div>

        <div className='verify-button-group-ver'>
          <label htmlFor="password" className="verify-label">Password*</label>
            <input
              type={"text" }
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className={isVerified ? 'verify-phone-disabled' : 'verify-phone-input'}
              required
            />
        </div>

        <div className='verify-button-group-ver'>
          <label htmlFor="confirmPassword" className="verify-label">Password*</label>
            <input
              type={"password"}
              id="confirmPassword"
              name="confirmPassword"
              value={formData.confirmPassword}
              onChange={handleChange}
              className={isVerified ? 'verify-phone-disabled' : 'verify-phone-input'}
              required
            />
        </div>
        </div>
        <div className="verify-form-group">
          <input
            type="checkbox"
            id="agreeToTerms"
            name="agreeToTerms"
            checked={formData.agreeToTerms}
            onChange={handleChange}
            className=""
            required
          />
          <label htmlFor="agreeToTerms" className="verify-label">
            I agree with Ask IT{' '}
            <a id='SignUpDetailsForm-a' href="#" className="verify-label">
              Terms of Service
            </a>
            ,{' '}
            <a id='SignUpDetailsForm-a' href="#" className="verify-label">
              Privacy Policy
            </a>{' '}
            and{' '}
            <a id='SignUpDetailsForm-a' href="#" className="verify-label">
              default Notification Settings
            </a>
          </label>
        </div>

        <button
        id='SignUpDetailsForm-button'
          type="submit"
          className="verify-label"
          onClick={() => navigate("/Search")}
        >
          Create an account
        </button>

        <p className="verify-label">
          Already have an account?{' '}
          <a id='SignUpDetailsForm-a' href="#" className="">
            Sign In
          </a>
        </p>
    </div>
  );
}
export default Form2;