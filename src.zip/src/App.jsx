import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import NavBar from "./Pages/NavBar.jsx";
import Home from "./Pages/Home.jsx";
import Search from "./Pages/Search-Filter.jsx";
import Signup from "./Pages/Signup.jsx";
import Dashboard from "./Pages/Dashboard.jsx";
import Verify from "./Pages/Verify.jsx";
import Footer from "./components/Home/HomeFooter";
import Login from "./components/Navtopage/Login.jsx";

const App = () => {
  return (
    
    <Router>
      <NavBar />   
      < Login />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/Search" element={<Search />} />
        <Route path="/Provider-Signup" element={<Signup />} />
        <Route path="/Consumer-Signup" element={<Verify />} />
        <Route path="/Dashboard" element={<Dashboard/>} />
        <Route path="/Dashboard" element={<Dashboard/>} />
      </Routes>
      <Footer />  
    </Router>
  );
};

export default App;
